# 待辦清單網站 [連結](https://lockingwang.github.io/Work-toDoList/#)

![](https://github.com/LockingWang/Work-toDoList/blob/main/img/readme-img%20%E7%99%BB%E5%85%A5.jpg)


## 作品介紹
在學習JavaScript過程中，嘗試串接後端的API，來完成一個有待辦清單功能的網站。


# 網頁畫面

## 登入與註冊
![](https://github.com/LockingWang/Work-toDoList/blob/main/img/readme-img%20%E7%99%BB%E5%85%A5.jpg)
![](https://github.com/LockingWang/Work-toDoList/blob/main/img/readme-img%20%E8%A8%BB%E5%86%8A.jpg)

## 待辦清單頁面
![](https://github.com/LockingWang/Work-toDoList/blob/main/img/readme-img%20%E6%93%8D%E4%BD%9C%E9%A0%81%E9%9D%A2.jpg)

## 可切換分頁
![](https://github.com/LockingWang/Work-toDoList/blob/main/img/readme-img%20%E5%88%87%E6%8F%9B%E5%88%86%E9%A0%81.gif)
